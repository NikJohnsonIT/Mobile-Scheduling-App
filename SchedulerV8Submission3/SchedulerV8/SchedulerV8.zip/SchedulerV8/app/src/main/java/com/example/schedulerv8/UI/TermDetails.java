package com.example.schedulerv8.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;


import com.example.schedulerv8.Adapters.CourseAdapter;
import com.example.schedulerv8.Database.Repository;
import com.example.schedulerv8.Entities.Course;
import com.example.schedulerv8.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TermDetails extends AppCompatActivity {
    Repository repository;
    EditText termDetailsTermIdFromDB;
    EditText termDetailsTermName;
    EditText termDetailsTermStartDate;
    EditText termDetailsTermEndDate;
    DatePickerDialog.OnDateSetListener termStartDate;
    DatePickerDialog.OnDateSetListener termEndDate;
    final Calendar termStartCalendar = Calendar.getInstance();
    final Calendar termEndCalendar = Calendar.getInstance();

    Button saveTermButton;
    Button deleteTermButton;


    //todo refactor/rename variable to termid
    int termId;
    String termName;
    String aStartDate;
    String aEndDate;

    List<Course> associatedCourses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        repository = new Repository(getApplication());
        setContentView(R.layout.activity_term_details);
        //findviewID first, set references for controls.
        //on click
        //date set
        termDetailsTermIdFromDB=findViewById(R.id.termEditDetailsTermIDNonEditField);
        termDetailsTermName=findViewById(R.id.termEditDetailsTermNameEdit);
        termDetailsTermStartDate=findViewById(R.id.termEditDetailsTermStartDatePicker);
        termDetailsTermEndDate=findViewById(R.id.termEditDetailsTermEndDatePicker);
        RecyclerView associatedCoursesRecyclerView = (RecyclerView) findViewById(R.id.associatedCoursesRecyclerView);
        saveTermButton=findViewById(R.id.termSaveBtn);
        deleteTermButton=findViewById(R.id.termDeleteBtn);
        String schedulerDateFormat = "MM/dd/yyyy";
        SimpleDateFormat sdf = new SimpleDateFormat(schedulerDateFormat, Locale.US);
        final CourseAdapter courseAdapter = new CourseAdapter(this);
        associatedCoursesRecyclerView.setAdapter(courseAdapter);
        associatedCoursesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<Course> associatedCourses = repository.getAssociatedCourses(termId);
        courseAdapter.setAssociatedCourses(associatedCourses);


        aStartDate = getIntent().getStringExtra("term_start_date");
        aEndDate = getIntent().getStringExtra("term_end_date");
        termName = getIntent().getStringExtra("term_title");
        termDetailsTermIdFromDB.setText(String.valueOf(termId));
        termDetailsTermName.setText(termName);
        termId = getIntent().getIntExtra("term_id", -1);

            if (aStartDate != "") {
                termDetailsTermStartDate.setText(aStartDate);
            } else {
                termDetailsTermStartDate.setText(sdf.format(new Date()));
            }
        }

    }
