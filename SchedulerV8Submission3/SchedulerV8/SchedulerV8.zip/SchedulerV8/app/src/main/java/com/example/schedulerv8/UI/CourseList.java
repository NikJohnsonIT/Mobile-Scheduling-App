package com.example.schedulerv8.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.schedulerv8.R;

public class CourseList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_list);
    }
}