package com.example.schedulerv8.Adapters;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.schedulerv8.R;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.schedulerv8.Entities.Course;
import com.example.schedulerv8.UI.CourseDetails;

import java.util.List;


public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder> {
    private List<Course> mAllCourses;
    private List<Course> mAssociatedCourses;

    class CourseViewHolder extends RecyclerView.ViewHolder {
        private final TextView courseItemView;
        private CourseViewHolder(View itemView){
            super(itemView);
            courseItemView=itemView.findViewById(R.id.courseListItemTextView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    final Course current = mAllCourses.get(position);
                    Intent intent = new Intent(context, CourseDetails.class);
                    intent.putExtra("course_term_id", current.getTermId());
                    intent.putExtra("course_id", current.getCourseId());
                    intent.putExtra("course_title", current.getCourseTitle());
                    intent.putExtra("status", current.getStatus());
                    context.startActivity(intent);
                }
            });
        }
    }
    private final Context context;
    private final LayoutInflater mInflater;

    public CourseAdapter(Context context){
        mInflater = LayoutInflater.from(context);
        this.context = context;

    }
    @NonNull
    @Override
    public CourseAdapter.CourseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.course_list_item,parent,false);
        return new CourseViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CourseAdapter.CourseViewHolder holder, int position) {
        if(mAllCourses!=null){
            Course currentCourse=mAllCourses.get(position);
            String courseName=currentCourse.getCourseTitle();
            holder.courseItemView.setText(courseName);
        } else {
            holder.courseItemView.setText("No Courses");
        }
    }

    @Override
    public int getItemCount() {
        return mAllCourses.size();
    }



    public void setAllCourses(List<Course> allCourses) {
        mAllCourses = allCourses;
        notifyDataSetChanged();
    }

    public void setAssociatedCourses(List<Course> associatedCourses) {
        mAssociatedCourses = associatedCourses;
        notifyDataSetChanged();
    }
}
