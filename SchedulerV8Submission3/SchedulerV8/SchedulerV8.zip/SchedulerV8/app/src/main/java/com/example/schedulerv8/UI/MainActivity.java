package com.example.schedulerv8.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


import com.example.schedulerv8.Database.Repository;
import com.example.schedulerv8.Entities.Course;
import com.example.schedulerv8.Entities.Term;
import com.example.schedulerv8.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Repository repository = new Repository(getApplication());

        //Define Buttons. Only use floating action button if it is the only button as per android documentation.
        Button termButton = findViewById(R.id.mainScreenTermsButton);
        Button courseButton = findViewById(R.id.mainScreenCoursesButton);
        Button assessmentButton = findViewById(R.id.mainScreenAssessmentsButton);

        //add menu option to add sample data (in on Create)
        //onClickListeners for each button
        termButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //This is telling the app where it is and where it is going following the button being clicked/pushed.
                Intent intent = new Intent(MainActivity.this, TermsList.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==R.id.addSampleDataTest){
            Repository repository = new Repository(getApplication());
            Term sampleTerm1 = new Term( "sample 1", "06/20/2024", "01/20/2024");
            repository.insert(sampleTerm1);
            Course sampleCourse1 = new Course(1, 1, "SampleCourse", "12/07/2023", "12/12/2023", Course.Status.PLAN_TO_TAKE, "Ex Name", "ex phone", "ex email", "ex note");
            repository.insert(sampleCourse1);
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

}
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch(item.getItemId()) {
//            case R.id.addSampleDataTest:
//                Repository repository = new Repository(getApplication());
//                Term sampleTerm1 = new Term(1, "Sample 1", "06/20/2024", "07/20/2024");
//                repository.insert(sampleTerm1);
//                return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }
//}